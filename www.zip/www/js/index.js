
var app = {
   
    initialize: function() {
        this.bindEvents();
    },
   
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
        document.getElementById("btnweather").addEventListener("click", getweather);
    },

    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:none;');

        console.log('Received Event: ' + id);
    }
};

function getweather(){

   
if (navigator.geolocation){
    navigator.geolocation.getCurrentPosition(function(position)
    {
        $("#geoloc").html("latitude:" + position.coords.latitude + "<br> longitude: " + position.coords.longitude);

        var lat = position.coords.latitude ;
        var long = position.coords.longitude;
      
      
        var weatherURL= "http://api.openweathermap.org/data/2.5/weather?lat="+lat+"&lon="+long+"&APPID=41710850c9d65eaa3820df3d096c5fde";
        $.getJSON(weatherURL).done(function(data){
            $("#currentlocation").html("currentlocation:" + data.name);


            $("#currtemp").html("Current Temp:" + data.main.temp);

            $("#mainTemp").html("Main Weather condition:" + data.weather[0].main);
            $("#currTempInfo").html("Sub Weather Condition :" + data.weather[0].description);

            var minconvert = data.main.temp_min-273.15;
            $("#mintemp").html("Minimum Temp:" + minconvert);

            var maxconvert = data.main.temp_max-273.15;
            $("#maxtemp").html("Maximum Temp:" + maxconvert);

            var windspeed = data.wind.speed*18/5;
            $("#windspeed").html("Wind Speed:" + windspeed);
            

            $("#humidity").html("Environmental Humidity:" + data.main.humidity);
            $("#pressure").html("Pressure:" + data.main.pressure);
            

            var abc = data.sys.sunrise;
            var efg = new Date(0);
            efg.setUTCSeconds(abc);
            $("#sunrise").html("sunrise:" + efg);

            var abc = data.sys.sunset;
            var x = new Date(0);
            x.setUTCSeconds(abc);
            $("#sunset").html("sunset:" + x);
            
        });
    },function(er){
        alert(er.message);
    });
}
}